package com.example.lab1q2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editTextTextPersonName16);

    }

    public void displayMessage(View view){
        String enteredTextByUser = editText.getText().toString();
        Toast.makeText(getApplicationContext(), "Movie - "+enteredTextByUser+" - has been added", Toast.LENGTH_LONG).show();
    }
}

